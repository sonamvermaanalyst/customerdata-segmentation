Software Required:
	->python 3.8.2

Library Installed:
	->Pandas
	->Numpy

Code Flow:

1. Function: convert_json_data_into_csv

-> This is used to parse json file and convert that data into csv file by using pandas libirary.

-> to_csv() method is used to convert it 

-> Parameters: input_josn_file and output_csv_file as paraemters are required to feed into this function

2. Convert this csv file data into pandas dataframe to apply the filter logic on top of this 

3. Define the case conditions to mark each customers into a segment as per their spent 

4. Write data back into csv file as output from dataframe using numpy lib.(i.e. Right now storing the out file into local dir , but we can store it to any other location also by providing the path like AWS S3, GCS etc.)

5. Execute the main method to perform the operations