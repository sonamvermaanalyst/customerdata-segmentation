import pandas as pd
import numpy as np

"""
Lib:
Pandas
Numpy

DocSting:
This following code is created to achieve the result from customer data 
-> We read a customer dataset in json format
-> Parse and Converted into json into csv file
-> Convert csv file data into pandas dataframe for apply business logic
-> Created the condition and create new column to store the result data after applying the loc
-> Stored the customer segmentation data into new csv file as output 

"""


# Function to parse json data and convert into csv format and put into csv file
def convert_json_data_into_csv(input_json_file_name, output_csv_file_name):
    # Load JSON data into a Pandas DataFrame
    with open(input_json_file_name, 'r') as file:
        data = pd.read_json(file)
    # Convert DataFrame to CSV and save it
    data.to_csv(output_csv_file_name, index=False)

    return print("Data Conversion completed from JSON to CSV file")


def main():

    input_json_file_name = 'input_customer_data.json'
    output_csv_file_name = 'converted_customer_csv_data.csv'

    convert_json_data_into_csv(input_json_file_name, output_csv_file_name)

    # Read CSV file into a Pandas DataFrame
    customer_df = pd.read_csv(output_csv_file_name)
    # print(customer_df)

    # Apply logic and create a new customer segment column based on conditions
    conditions = [
        (customer_df['purchase_amount'] <= 100),
        (customer_df['purchase_amount'] > 100) & (customer_df['purchase_amount'] <= 500),
        (customer_df['purchase_amount'] > 500)
    ]

    segment_name = ['Low', 'Medium', 'High']

    # Create Segment column in dataframe based on the above conditions
    customer_df['Segment'] = np.select(conditions, segment_name, default='Unknown')
    # print(customer_df)

    # Write customers Segmentation data into csv file as output for segmented data
    customer_df.to_csv('customer_segmentation_output_data.csv', index=False)


if __name__ == '__main__':
    main()
